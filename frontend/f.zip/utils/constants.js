// Default image URL for community placeholders
export const DEFAULT_COMMUNITY_IMAGE_URL =
	"https://firebasestorage.googleapis.com/v0/b/maternify-4de04.firebasestorage.app/o/community%2FDefaultCommunityPlaceholder.webp?alt=media&token=8079a82f-a259-463b-80ad-f8c8ba1d50c4"
